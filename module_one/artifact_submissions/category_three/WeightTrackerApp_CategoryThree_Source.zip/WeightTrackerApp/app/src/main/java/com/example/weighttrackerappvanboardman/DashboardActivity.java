package com.example.weighttrackerappvanboardman;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

@SuppressWarnings("deprecation")
public class DashboardActivity extends AppCompatActivity {
    public static final String EXTRA_USER_ID = "com.example.weighttrackerappvanboardman.USER_ID";
    private static final int REQUEST_ADD_WEIGHT = 100;
    private static final int REQUEST_EDIT_WEIGHT = 101;
    private static final int REQUEST_GOAL = 102;
    private static final int REQUEST_SMS = 103;

    private long userId;
    private DatabaseHelper databaseHelper;
    private TableLayout weightHistoryTable;
    private TextView currentGoalValueText;
    private TextView currentGoalSupportingText;
    private TextView latestWeightValueText;
    private TextView latestWeightSupportingText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);
        applySystemBarPadding();

        userId = getIntent().getLongExtra(EXTRA_USER_ID, -1L);
        if (userId <= 0) {
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);
        weightHistoryTable = findViewById(R.id.weightHistoryTable);
        currentGoalValueText = findViewById(R.id.currentGoalValueText);
        currentGoalSupportingText = findViewById(R.id.currentGoalSupportingText);
        latestWeightValueText = findViewById(R.id.latestWeightValueText);
        latestWeightSupportingText = findViewById(R.id.latestWeightSupportingText);

        MaterialToolbar toolbar = findViewById(R.id.dashboardToolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        findViewById(R.id.addWeightButton).setOnClickListener(v -> {
            Intent intent = new Intent(this, AddWeightActivity.class);
            intent.putExtra(AddWeightActivity.EXTRA_USER_ID, userId);
            startActivityForResult(intent, REQUEST_ADD_WEIGHT);
        });
        findViewById(R.id.updateGoalButton).setOnClickListener(v -> {
            Intent intent = new Intent(this, GoalWeightActivity.class);
            intent.putExtra(GoalWeightActivity.EXTRA_USER_ID, userId);
            startActivityForResult(intent, REQUEST_GOAL);
        });
        findViewById(R.id.smsAlertsButton).setOnClickListener(v -> {
            Intent intent = new Intent(this, NotificationSettingsActivity.class);
            intent.putExtra(NotificationSettingsActivity.EXTRA_USER_ID, userId);
            startActivityForResult(intent, REQUEST_SMS);
        });

        loadDashboard();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_ADD_WEIGHT
                || requestCode == REQUEST_EDIT_WEIGHT
                || requestCode == REQUEST_GOAL
                || requestCode == REQUEST_SMS)
                && resultCode == Activity.RESULT_OK) {
            loadDashboard();
        }
    }

    private void loadDashboard() {
        GoalSettings goal = databaseHelper.getGoalSettings(userId);
        WeightEntry latestEntry = databaseHelper.getLatestWeightEntry(userId);
        ArrayList<WeightEntry> entries = databaseHelper.getWeightEntries(userId);
        renderSummary(goal, latestEntry);
        renderWeightRows(entries, goal);
        evaluateGoalAlert(latestEntry, goal);
    }

    private void renderSummary(GoalSettings goal, WeightEntry latestEntry) {
        if (goal == null) {
            currentGoalValueText.setText(R.string.goal_not_set_value);
            currentGoalSupportingText.setText(R.string.goal_not_set_supporting);
        } else {
            currentGoalValueText.setText(getString(R.string.goal_value_format, goal.getTargetWeight()));
            int directionText = GoalSettings.DIRECTION_ABOVE.equals(goal.getDirection())
                    ? R.string.goal_direction_above_summary
                    : R.string.goal_direction_below_summary;
            currentGoalSupportingText.setText(directionText);
        }

        if (latestEntry == null) {
            latestWeightValueText.setText(R.string.latest_weight_empty_value);
            latestWeightSupportingText.setText(R.string.latest_weight_empty_supporting);
        } else {
            latestWeightValueText.setText(getString(R.string.weight_value_format, latestEntry.getWeight()));
            latestWeightSupportingText.setText(WeightDateUtils.toDisplayDate(latestEntry.getEntryDate()));
        }
    }

    private void renderWeightRows(ArrayList<WeightEntry> entries, GoalSettings goal) {
        while (weightHistoryTable.getChildCount() > 1) {
            weightHistoryTable.removeViewAt(1);
        }

        if (entries.isEmpty()) {
            TableRow row = new TableRow(this);
            TextView emptyCell = createCell(getString(R.string.no_weight_entries_message), 460);
            TableRow.LayoutParams params = new TableRow.LayoutParams();
            params.span = 4;
            row.addView(emptyCell, params);
            weightHistoryTable.addView(row);
            return;
        }

        for (WeightEntry entry : entries) {
            weightHistoryTable.addView(buildEntryRow(entry, goal));
        }
    }

    private TableRow buildEntryRow(WeightEntry entry, GoalSettings goal) {
        TableRow row = new TableRow(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        row.addView(createCell(WeightDateUtils.toDisplayDate(entry.getEntryDate()), 120));
        row.addView(createCell(getString(R.string.weight_value_format, entry.getWeight()), 120));
        String goalText = goal == null
                ? getString(R.string.goal_not_set_value)
                : getString(R.string.goal_value_format, goal.getTargetWeight());
        row.addView(createCell(goalText, 110));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, 0, 0, 0);

        MaterialButton editButton = new MaterialButton(this);
        editButton.setText(R.string.action_edit);
        editButton.setMinHeight(getResources().getDimensionPixelSize(R.dimen.min_touch_target));
        editButton.setOnClickListener(v -> openEditEntry(entry.getId()));

        MaterialButton deleteButton = new MaterialButton(this);
        deleteButton.setText(R.string.action_delete);
        deleteButton.setMinHeight(getResources().getDimensionPixelSize(R.dimen.min_touch_target));
        deleteButton.setOnClickListener(v -> deleteEntry(entry.getId()));

        actions.addView(editButton);
        actions.addView(deleteButton);
        row.addView(actions, new TableRow.LayoutParams(dp(190), TableRow.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private TextView createCell(String text, int widthDp) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium);
        int padding = getResources().getDimensionPixelSize(R.dimen.table_cell_padding);
        textView.setPadding(padding, padding, padding, padding);
        textView.setLayoutParams(new TableRow.LayoutParams(dp(widthDp), TableRow.LayoutParams.WRAP_CONTENT));
        return textView;
    }

    private void deleteEntry(long entryId) {
        databaseHelper.deleteWeight(entryId);
        Snackbar.make(weightHistoryTable, R.string.weight_deleted_message, Snackbar.LENGTH_LONG).show();
        loadDashboard();
    }

    private void openEditEntry(long entryId) {
        Intent intent = new Intent(this, AddWeightActivity.class);
        intent.putExtra(AddWeightActivity.EXTRA_USER_ID, userId);
        intent.putExtra(AddWeightActivity.EXTRA_ENTRY_ID, entryId);
        startActivityForResult(intent, REQUEST_EDIT_WEIGHT);
    }

    private void evaluateGoalAlert(WeightEntry latestEntry, GoalSettings goal) {
        if (goal == null
                || latestEntry == null
                || !goal.isGoalReached(latestEntry.getWeight())
                || !goal.isSmsEnabled()
                || goal.getLastNotifiedEntryId() == latestEntry.getId()) {
            return;
        }

        boolean canSend = SmsAlertManager.canSendSms(this);
        boolean hasPhone = goal.getPhoneNumber() != null && !goal.getPhoneNumber().trim().isEmpty();
        if (canSend && hasPhone
                && SmsAlertManager.sendGoalReachedSms(this, goal.getPhoneNumber(), latestEntry, goal)) {
            databaseHelper.markGoalAlertSent(userId, latestEntry.getId());
            Snackbar.make(weightHistoryTable, R.string.goal_sms_sent_message, Snackbar.LENGTH_LONG).show();
        } else {
            Snackbar.make(weightHistoryTable, R.string.goal_sms_unavailable_message, Snackbar.LENGTH_LONG).show();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void applySystemBarPadding() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
