package com.example.weighttrackerappvanboardman;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class NotificationSettingsActivity extends AppCompatActivity {
    public static final String EXTRA_USER_ID = "com.example.weighttrackerappvanboardman.USER_ID";

    private long userId;
    private DatabaseHelper databaseHelper;
    private TextInputEditText phoneNumberInput;
    private MaterialSwitch smsAlertSwitch;
    private TextView smsPermissionStatusText;
    private boolean suppressSwitchListener;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                boolean granted = Boolean.TRUE.equals(isGranted);
                if (granted) {
                    saveSmsSettings(true);
                    Snackbar.make(smsPermissionStatusText,
                            R.string.sms_permission_granted_message,
                            Snackbar.LENGTH_LONG).show();
                } else {
                    databaseHelper.updateSmsSettings(userId, false, getPhoneNumber());
                    updateSmsStatus(false, false);
                    Snackbar.make(smsPermissionStatusText,
                            R.string.sms_permission_denied_message,
                            Snackbar.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notification_settings);
        applySystemBarPadding();

        userId = getIntent().getLongExtra(EXTRA_USER_ID, -1L);
        if (userId <= 0) {
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        smsAlertSwitch = findViewById(R.id.smsAlertSwitch);
        smsPermissionStatusText = findViewById(R.id.smsPermissionStatusText);

        MaterialToolbar toolbar = findViewById(R.id.smsSettingsToolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        loadSmsSettings();

        smsAlertSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!suppressSwitchListener) {
                saveSmsSettings(isChecked);
            }
        });

        findViewById(R.id.requestSmsPermissionButton).setOnClickListener(v -> {
            if (hasSmsPermission()) {
                saveSmsSettings(true);
            } else {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        findViewById(R.id.continueWithoutSmsButton).setOnClickListener(v -> {
            setResult(Activity.RESULT_OK);
            finish();
        });
    }

    private void loadSmsSettings() {
        GoalSettings settings = databaseHelper.getGoalSettings(userId);
        if (settings != null) {
            phoneNumberInput.setText(settings.getPhoneNumber());
        }
        boolean permissionGranted = hasSmsPermission();
        boolean smsEnabled = settings != null && settings.isSmsEnabled();
        updateSmsStatus(permissionGranted, smsEnabled && permissionGranted);
    }

    private void saveSmsSettings(boolean requestedEnabled) {
        GoalSettings settings = databaseHelper.getGoalSettings(userId);
        if (settings == null) {
            updateSmsStatus(hasSmsPermission(), false);
            showMessage(R.string.goal_not_set_sms_message);
            return;
        }

        String phoneNumber = getPhoneNumber();
        if (requestedEnabled && !hasPhoneNumber()) {
            databaseHelper.updateSmsSettings(userId, false, phoneNumber);
            updateSmsStatus(hasSmsPermission(), false);
            showMessage(R.string.phone_required_message);
            return;
        }

        if (requestedEnabled && !hasSmsPermission()) {
            databaseHelper.updateSmsSettings(userId, false, phoneNumber);
            updateSmsStatus(false, false);
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            return;
        }

        boolean smsEnabled = requestedEnabled && hasSmsPermission();
        databaseHelper.updateSmsSettings(userId, smsEnabled, phoneNumber);
        updateSmsStatus(hasSmsPermission(), smsEnabled);
        setResult(Activity.RESULT_OK);
        showMessage(smsEnabled ? R.string.sms_enabled_message : R.string.sms_status_disabled);
    }

    private boolean hasPhoneNumber() {
        return !getPhoneNumber().isEmpty();
    }

    private String getPhoneNumber() {
        return phoneNumberInput.getText() == null
                ? ""
                : phoneNumberInput.getText().toString().trim();
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updateSmsStatus(boolean permissionGranted, boolean smsEnabled) {
        suppressSwitchListener = true;
        smsAlertSwitch.setChecked(permissionGranted && smsEnabled);
        suppressSwitchListener = false;

        if (permissionGranted && smsEnabled) {
            smsPermissionStatusText.setText(R.string.sms_status_granted);
        } else if (!permissionGranted) {
            smsPermissionStatusText.setText(R.string.sms_status_not_granted);
        } else {
            smsPermissionStatusText.setText(R.string.sms_status_disabled);
        }
    }

    private void showMessage(int messageId) {
        Snackbar.make(smsPermissionStatusText, messageId, Snackbar.LENGTH_LONG).show();
    }

    private void applySystemBarPadding() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
