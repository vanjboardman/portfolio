package com.example.weighttrackerappvanboardman;

import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private TextInputEditText usernameInput;
    private TextInputEditText passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = new DatabaseHelper(this);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        findViewById(R.id.loginButton).setOnClickListener(v -> handleLogin());
        findViewById(R.id.createAccountButton).setOnClickListener(v -> handleCreateAccount());
    }

    private void handleLogin() {
        String username = getInputText(usernameInput).trim();
        String password = getInputText(passwordInput);
        if (!validateCredentials(username, password)) {
            return;
        }

        String passwordHash = PasswordUtils.hashPassword(password);
        long userId = databaseHelper.findUserIdForLogin(username, passwordHash);
        if (userId > 0) {
            openDashboard(userId);
        } else {
            showMessage(R.string.invalid_login_message);
        }
    }

    private void handleCreateAccount() {
        String username = getInputText(usernameInput).trim();
        String password = getInputText(passwordInput);
        if (!validateCredentials(username, password)) {
            return;
        }
        if (password.length() < 4) {
            showMessage(R.string.password_too_short_message);
            return;
        }
        if (databaseHelper.usernameExists(username)) {
            showMessage(R.string.account_exists_message);
            return;
        }

        try {
            String passwordHash = PasswordUtils.hashPassword(password);
            long userId = databaseHelper.createUser(username, passwordHash);
            showMessage(R.string.account_created_message);
            openDashboard(userId);
        } catch (SQLiteConstraintException exception) {
            showMessage(R.string.account_exists_message);
        }
    }

    private boolean validateCredentials(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            showMessage(R.string.empty_credentials_message);
            return false;
        }
        return true;
    }

    private void openDashboard(long userId) {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.putExtra(DashboardActivity.EXTRA_USER_ID, userId);
        startActivity(intent);
    }

    private String getInputText(TextInputEditText input) {
        return input.getText() == null ? "" : input.getText().toString();
    }

    private void showMessage(int messageId) {
        Snackbar.make(findViewById(R.id.main), messageId, Snackbar.LENGTH_LONG).show();
    }
}
