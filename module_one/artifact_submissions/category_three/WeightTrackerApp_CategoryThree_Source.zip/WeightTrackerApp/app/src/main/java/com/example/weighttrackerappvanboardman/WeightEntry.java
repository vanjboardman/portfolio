package com.example.weighttrackerappvanboardman;

public class WeightEntry {
    private final long id;
    private final long userId;
    private final String entryDate;
    private final double weight;

    public WeightEntry(long id, long userId, String entryDate, double weight) {
        this.id = id;
        this.userId = userId;
        this.entryDate = entryDate;
        this.weight = weight;
    }

    public long getId() {
        return id;
    }

    public long getUserId() {
        return userId;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public double getWeight() {
        return weight;
    }
}
