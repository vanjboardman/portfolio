package com.example.weighttrackerappvanboardman;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

@SuppressWarnings("deprecation")
public final class SmsAlertManager {
    private SmsAlertManager() {
    }

    public static boolean canSendSms(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean sendGoalReachedSms(Context context, String phoneNumber,
                                             WeightEntry entry, GoalSettings goal) {
        if (!canSendSms(context) || phoneNumber == null || phoneNumber.trim().isEmpty()) {
            return false;
        }

        try {
            SmsManager.getDefault().sendTextMessage(
                    phoneNumber.trim(),
                    null,
                    buildGoalMessage(entry, goal),
                    null,
                    null);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    private static String buildGoalMessage(WeightEntry entry, GoalSettings goal) {
        String displayDate = WeightDateUtils.toDisplayDate(entry.getEntryDate());
        return "Goal reached: " + entry.getWeight() + " lb on " + displayDate
                + " meets your " + goal.getTargetWeight() + " lb goal.";
    }
}
