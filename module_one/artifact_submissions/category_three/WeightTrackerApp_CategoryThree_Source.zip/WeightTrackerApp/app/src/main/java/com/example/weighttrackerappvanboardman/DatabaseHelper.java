package com.example.weighttrackerappvanboardman;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    private static final String TABLE_GOAL_SETTINGS = "goal_settings";

    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD_HASH = "password_hash";
    private static final String COLUMN_CREATED_AT = "created_at";
    private static final String COLUMN_ENTRY_DATE = "entry_date";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_UPDATED_AT = "updated_at";
    private static final String COLUMN_TARGET_WEIGHT = "target_weight";
    private static final String COLUMN_DIRECTION = "direction";
    private static final String COLUMN_SMS_ENABLED = "sms_enabled";
    private static final String COLUMN_PHONE_NUMBER = "phone_number";
    private static final String COLUMN_LAST_NOTIFIED_ENTRY_ID = "last_notified_entry_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COLUMN_PASSWORD_HASH + " TEXT NOT NULL, "
                + COLUMN_CREATED_AT + " INTEGER NOT NULL"
                + ")");

        db.execSQL("CREATE TABLE " + TABLE_WEIGHT_ENTRIES + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USER_ID + " INTEGER NOT NULL, "
                + COLUMN_ENTRY_DATE + " TEXT NOT NULL, "
                + COLUMN_WEIGHT + " REAL NOT NULL, "
                + COLUMN_CREATED_AT + " INTEGER NOT NULL, "
                + COLUMN_UPDATED_AT + " INTEGER NOT NULL, "
                + "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS
                + "(" + COLUMN_ID + ") ON DELETE CASCADE, "
                + "UNIQUE(" + COLUMN_USER_ID + ", " + COLUMN_ENTRY_DATE + ")"
                + ")");

        db.execSQL("CREATE TABLE " + TABLE_GOAL_SETTINGS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USER_ID + " INTEGER NOT NULL UNIQUE, "
                + COLUMN_TARGET_WEIGHT + " REAL NOT NULL, "
                + COLUMN_DIRECTION + " TEXT NOT NULL, "
                + COLUMN_SMS_ENABLED + " INTEGER NOT NULL DEFAULT 0, "
                + COLUMN_PHONE_NUMBER + " TEXT, "
                + COLUMN_LAST_NOTIFIED_ENTRY_ID + " INTEGER, "
                + COLUMN_UPDATED_AT + " INTEGER NOT NULL, "
                + "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS
                + "(" + COLUMN_ID + ") ON DELETE CASCADE"
                + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public long createUser(String username, String passwordHash) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD_HASH, passwordHash);
        values.put(COLUMN_CREATED_AT, System.currentTimeMillis());
        return getWritableDatabase().insertOrThrow(TABLE_USERS, null, values);
    }

    public long findUserIdForLogin(String username, String passwordHash) {
        String[] columns = {COLUMN_ID};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD_HASH + " = ?";
        String[] selectionArgs = {username, passwordHash};
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS, columns, selection, selectionArgs, null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID));
            }
            return -1L;
        }
    }

    public boolean usernameExists(String username) {
        String[] columns = {COLUMN_ID};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS, columns, selection, selectionArgs, null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    public long insertWeight(long userId, String databaseDate, double weight) {
        long now = System.currentTimeMillis();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_ENTRY_DATE, databaseDate);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_CREATED_AT, now);
        values.put(COLUMN_UPDATED_AT, now);
        return getWritableDatabase().insertOrThrow(TABLE_WEIGHT_ENTRIES, null, values);
    }

    public int updateWeight(long entryId, String databaseDate, double weight) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ENTRY_DATE, databaseDate);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_UPDATED_AT, System.currentTimeMillis());
        return getWritableDatabase().update(
                TABLE_WEIGHT_ENTRIES,
                values,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(entryId)});
    }

    public int deleteWeight(long entryId) {
        return getWritableDatabase().delete(
                TABLE_WEIGHT_ENTRIES,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(entryId)});
    }

    public WeightEntry getWeightEntry(long entryId) {
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = {String.valueOf(entryId)};
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHT_ENTRIES, null, selection, selectionArgs, null, null, null)) {
            if (cursor.moveToFirst()) {
                return weightEntryFromCursor(cursor);
            }
            return null;
        }
    }

    public ArrayList<WeightEntry> getWeightEntries(long userId) {
        ArrayList<WeightEntry> entries = new ArrayList<>();
        String selection = COLUMN_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};
        String orderBy = COLUMN_ENTRY_DATE + " DESC, " + COLUMN_ID + " DESC";
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHT_ENTRIES, null, selection, selectionArgs, null, null, orderBy)) {
            while (cursor.moveToNext()) {
                entries.add(weightEntryFromCursor(cursor));
            }
        }
        return entries;
    }

    public WeightEntry getLatestWeightEntry(long userId) {
        String selection = COLUMN_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};
        String orderBy = COLUMN_ENTRY_DATE + " DESC, " + COLUMN_ID + " DESC";
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHT_ENTRIES, null, selection, selectionArgs, null, null, orderBy, "1")) {
            if (cursor.moveToFirst()) {
                return weightEntryFromCursor(cursor);
            }
            return null;
        }
    }

    public GoalSettings getGoalSettings(long userId) {
        String selection = COLUMN_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_GOAL_SETTINGS, null, selection, selectionArgs, null, null, null)) {
            if (cursor.moveToFirst()) {
                return goalSettingsFromCursor(cursor);
            }
            return null;
        }
    }

    public long upsertGoalSettings(long userId, double targetWeight, String direction,
                                   boolean smsEnabled, String phoneNumber) {
        GoalSettings existing = getGoalSettings(userId);
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_TARGET_WEIGHT, targetWeight);
        values.put(COLUMN_DIRECTION, direction);
        values.put(COLUMN_SMS_ENABLED, smsEnabled ? 1 : 0);
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);
        values.put(COLUMN_UPDATED_AT, System.currentTimeMillis());

        if (existing == null) {
            return getWritableDatabase().insertOrThrow(TABLE_GOAL_SETTINGS, null, values);
        }

        getWritableDatabase().update(
                TABLE_GOAL_SETTINGS,
                values,
                COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});
        return existing.getId();
    }

    public int updateSmsSettings(long userId, boolean smsEnabled, String phoneNumber) {
        GoalSettings existing = getGoalSettings(userId);
        if (existing == null) {
            return 0;
        }

        ContentValues values = new ContentValues();
        values.put(COLUMN_SMS_ENABLED, smsEnabled ? 1 : 0);
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);
        values.put(COLUMN_UPDATED_AT, System.currentTimeMillis());
        return getWritableDatabase().update(
                TABLE_GOAL_SETTINGS,
                values,
                COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});
    }

    public int markGoalAlertSent(long userId, long entryId) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_LAST_NOTIFIED_ENTRY_ID, entryId);
        values.put(COLUMN_UPDATED_AT, System.currentTimeMillis());
        return getWritableDatabase().update(
                TABLE_GOAL_SETTINGS,
                values,
                COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});
    }

    private WeightEntry weightEntryFromCursor(Cursor cursor) {
        return new WeightEntry(
                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ENTRY_DATE)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT)));
    }

    private GoalSettings goalSettingsFromCursor(Cursor cursor) {
        int notifiedIndex = cursor.getColumnIndexOrThrow(COLUMN_LAST_NOTIFIED_ENTRY_ID);
        long lastNotifiedEntryId = cursor.isNull(notifiedIndex) ? 0L : cursor.getLong(notifiedIndex);
        return new GoalSettings(
                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_TARGET_WEIGHT)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DIRECTION)),
                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_SMS_ENABLED)) == 1,
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE_NUMBER)),
                lastNotifiedEntryId);
    }
}
