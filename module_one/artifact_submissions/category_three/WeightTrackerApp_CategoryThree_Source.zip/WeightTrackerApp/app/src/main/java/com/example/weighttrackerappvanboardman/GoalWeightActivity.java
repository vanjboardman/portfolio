package com.example.weighttrackerappvanboardman;

import android.app.Activity;
import android.os.Bundle;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Locale;

public class GoalWeightActivity extends AppCompatActivity {
    public static final String EXTRA_USER_ID = "com.example.weighttrackerappvanboardman.USER_ID";

    private long userId;
    private DatabaseHelper databaseHelper;
    private TextInputEditText goalWeightInput;
    private RadioGroup goalDirectionGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_goal_weight);
        applySystemBarPadding();

        userId = getIntent().getLongExtra(EXTRA_USER_ID, -1L);
        if (userId <= 0) {
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);
        goalWeightInput = findViewById(R.id.goalWeightInput);
        goalDirectionGroup = findViewById(R.id.goalDirectionGroup);

        MaterialToolbar toolbar = findViewById(R.id.goalWeightToolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        loadGoalSettings();

        findViewById(R.id.saveGoalButton).setOnClickListener(v -> saveGoal());
        findViewById(R.id.cancelGoalButton).setOnClickListener(v -> finish());
    }

    private void loadGoalSettings() {
        GoalSettings goal = databaseHelper.getGoalSettings(userId);
        if (goal == null) {
            goalWeightInput.setText("");
            goalDirectionGroup.check(R.id.goalDirectionBelowRadio);
            return;
        }

        goalWeightInput.setText(String.format(Locale.US, "%.1f", goal.getTargetWeight()));
        if (GoalSettings.DIRECTION_ABOVE.equals(goal.getDirection())) {
            goalDirectionGroup.check(R.id.goalDirectionAboveRadio);
        } else {
            goalDirectionGroup.check(R.id.goalDirectionBelowRadio);
        }
    }

    private void saveGoal() {
        String goalText = getInputText(goalWeightInput).trim();
        if (!validateGoalInput(goalText)) {
            return;
        }

        double targetWeight = Double.parseDouble(goalText);
        GoalSettings existing = databaseHelper.getGoalSettings(userId);
        boolean smsEnabled = existing != null && existing.isSmsEnabled();
        String phoneNumber = existing == null ? "" : existing.getPhoneNumber();

        databaseHelper.upsertGoalSettings(
                userId,
                targetWeight,
                selectedGoalDirection(),
                smsEnabled,
                phoneNumber);
        showMessage(R.string.goal_saved_message);
        setResult(Activity.RESULT_OK);
        finish();
    }

    private String selectedGoalDirection() {
        if (goalDirectionGroup.getCheckedRadioButtonId() == R.id.goalDirectionAboveRadio) {
            return GoalSettings.DIRECTION_ABOVE;
        }
        return GoalSettings.DIRECTION_BELOW;
    }

    private boolean validateGoalInput(String goalText) {
        try {
            double goalWeight = Double.parseDouble(goalText);
            if (goalWeight <= 0) {
                showMessage(R.string.invalid_goal_message);
                return false;
            }
            return true;
        } catch (NumberFormatException exception) {
            showMessage(R.string.invalid_goal_message);
            return false;
        }
    }

    private String getInputText(TextInputEditText input) {
        return input.getText() == null ? "" : input.getText().toString();
    }

    private void showMessage(int messageId) {
        Snackbar.make(findViewById(R.id.main), messageId, Snackbar.LENGTH_LONG).show();
    }

    private void applySystemBarPadding() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
