package com.example.weighttrackerappvanboardman;

import android.app.Activity;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.time.format.DateTimeParseException;
import java.util.Locale;

public class AddWeightActivity extends AppCompatActivity {
    public static final String EXTRA_USER_ID = "com.example.weighttrackerappvanboardman.USER_ID";
    public static final String EXTRA_ENTRY_ID = "com.example.weighttrackerappvanboardman.ENTRY_ID";

    private long userId;
    private long entryId;
    private DatabaseHelper databaseHelper;
    private TextInputEditText dateInput;
    private TextInputEditText weightInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_weight);
        applySystemBarPadding();

        userId = getIntent().getLongExtra(EXTRA_USER_ID, -1L);
        entryId = getIntent().getLongExtra(EXTRA_ENTRY_ID, -1L);
        if (userId <= 0) {
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);

        MaterialToolbar toolbar = findViewById(R.id.addWeightToolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        if (entryId > 0) {
            loadEntryForEdit();
        } else {
            dateInput.setText(WeightDateUtils.todayForDisplay());
            weightInput.setText("");
        }

        findViewById(R.id.saveWeightButton).setOnClickListener(v -> saveWeight());
        findViewById(R.id.cancelAddWeightButton).setOnClickListener(v -> finish());
    }

    private void loadEntryForEdit() {
        WeightEntry entry = databaseHelper.getWeightEntry(entryId);
        if (entry == null || entry.getUserId() != userId) {
            finish();
            return;
        }

        dateInput.setText(WeightDateUtils.toDisplayDate(entry.getEntryDate()));
        weightInput.setText(String.format(Locale.US, "%.1f", entry.getWeight()));
    }

    private void saveWeight() {
        String dateText = getInputText(dateInput).trim();
        String weightText = getInputText(weightInput).trim();
        if (!validateWeightInput(dateText, weightText)) {
            return;
        }

        try {
            String databaseDate = WeightDateUtils.toDatabaseDate(dateText);
            double weight = Double.parseDouble(weightText);
            if (entryId > 0) {
                databaseHelper.updateWeight(entryId, databaseDate, weight);
                showMessage(R.string.weight_updated_message);
            } else {
                databaseHelper.insertWeight(userId, databaseDate, weight);
                showMessage(R.string.weight_saved_message);
            }
            setResult(Activity.RESULT_OK);
            finish();
        } catch (SQLiteConstraintException exception) {
            showMessage(R.string.duplicate_date_message);
        }
    }

    private boolean validateWeightInput(String dateText, String weightText) {
        try {
            WeightDateUtils.toDatabaseDate(dateText);
        } catch (DateTimeParseException exception) {
            showMessage(R.string.invalid_date_message);
            return false;
        }

        try {
            double weight = Double.parseDouble(weightText);
            if (weight <= 0) {
                showMessage(R.string.invalid_weight_message);
                return false;
            }
        } catch (NumberFormatException exception) {
            showMessage(R.string.invalid_weight_message);
            return false;
        }

        return true;
    }

    private String getInputText(TextInputEditText input) {
        return input.getText() == null ? "" : input.getText().toString();
    }

    private void showMessage(int messageId) {
        Snackbar.make(findViewById(R.id.main), messageId, Snackbar.LENGTH_LONG).show();
    }

    private void applySystemBarPadding() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
