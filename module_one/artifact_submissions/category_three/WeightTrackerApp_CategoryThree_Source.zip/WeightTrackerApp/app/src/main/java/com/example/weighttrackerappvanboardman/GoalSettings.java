package com.example.weighttrackerappvanboardman;

public class GoalSettings {
    public static final String DIRECTION_BELOW = "BELOW";
    public static final String DIRECTION_ABOVE = "ABOVE";

    private final long id;
    private final long userId;
    private final double targetWeight;
    private final String direction;
    private final boolean smsEnabled;
    private final String phoneNumber;
    private final long lastNotifiedEntryId;

    public GoalSettings(long id, long userId, double targetWeight, String direction,
                        boolean smsEnabled, String phoneNumber, long lastNotifiedEntryId) {
        this.id = id;
        this.userId = userId;
        this.targetWeight = targetWeight;
        this.direction = direction;
        this.smsEnabled = smsEnabled;
        this.phoneNumber = phoneNumber == null ? "" : phoneNumber;
        this.lastNotifiedEntryId = lastNotifiedEntryId;
    }

    public long getId() {
        return id;
    }

    public long getUserId() {
        return userId;
    }

    public double getTargetWeight() {
        return targetWeight;
    }

    public String getDirection() {
        return direction;
    }

    public boolean isSmsEnabled() {
        return smsEnabled;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public long getLastNotifiedEntryId() {
        return lastNotifiedEntryId;
    }

    public boolean isGoalReached(double currentWeight) {
        if (DIRECTION_ABOVE.equals(direction)) {
            return currentWeight >= targetWeight;
        }
        return currentWeight <= targetWeight;
    }
}
