package com.example.weighttrackerappvanboardman;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public final class WeightDateUtils {
    private static final DateTimeFormatter DISPLAY_FORMATTER =
            DateTimeFormatter.ofPattern("MM/dd/yyyy");
    private static final DateTimeFormatter DATABASE_FORMATTER =
            DateTimeFormatter.ISO_LOCAL_DATE;

    private WeightDateUtils() {
    }

    public static String todayForDisplay() {
        return LocalDate.now().format(DISPLAY_FORMATTER);
    }

    public static String toDatabaseDate(String displayDate) {
        LocalDate date = LocalDate.parse(displayDate.trim(), DISPLAY_FORMATTER);
        return date.format(DATABASE_FORMATTER);
    }

    public static String toDisplayDate(String databaseDate) {
        LocalDate date = LocalDate.parse(databaseDate.trim(), DATABASE_FORMATTER);
        return date.format(DISPLAY_FORMATTER);
    }
}
