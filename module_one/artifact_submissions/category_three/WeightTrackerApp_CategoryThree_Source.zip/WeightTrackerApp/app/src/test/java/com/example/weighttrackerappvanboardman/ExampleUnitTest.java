package com.example.weighttrackerappvanboardman;

import org.junit.Test;

import static org.junit.Assert.*;

public class ExampleUnitTest {
    @Test
    public void hashPassword_returnsLowercaseSha256Hex() {
        assertEquals(
                "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
                PasswordUtils.hashPassword("password"));
    }

    @Test
    public void isGoalReached_usesBelowDirectionByDefault() {
        GoalSettings goal = new GoalSettings(
                1L,
                2L,
                165.0,
                GoalSettings.DIRECTION_BELOW,
                false,
                "",
                0L);

        assertTrue(goal.isGoalReached(164.9));
        assertTrue(goal.isGoalReached(165.0));
        assertFalse(goal.isGoalReached(165.1));
    }

    @Test
    public void isGoalReached_usesAboveDirectionWhenSelected() {
        GoalSettings goal = new GoalSettings(
                1L,
                2L,
                180.0,
                GoalSettings.DIRECTION_ABOVE,
                false,
                "",
                0L);

        assertFalse(goal.isGoalReached(179.9));
        assertTrue(goal.isGoalReached(180.0));
        assertTrue(goal.isGoalReached(180.1));
    }

    @Test
    public void weightDateUtils_convertsBetweenDisplayAndDatabaseDates() {
        assertEquals("2026-06-13", WeightDateUtils.toDatabaseDate("06/13/2026"));
        assertEquals("06/13/2026", WeightDateUtils.toDisplayDate("2026-06-13"));
    }
}
